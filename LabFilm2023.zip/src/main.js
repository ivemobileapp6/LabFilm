import { createApp } from 'vue'
import App from './App.vue'
import { Quasar } from 'quasar';
//import '@quasar/extras/materials-icons/material-icons.css';
import 'quasar/dist/quasar.css';
import router from './route'


//import './assets/main.css'

//createApp(App).use(router).use(Quasar).mount('#app')
const app = createApp(App);
app.use(router);
app.use(Quasar);
app.mount('#app'); //must last
