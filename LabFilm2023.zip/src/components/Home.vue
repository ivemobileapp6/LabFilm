<template>
  <div v-if="error">
    <q-banner inline-actions class="text-white bg-red">
  Sorry that there is a problem connecting to the API
      </q-banner>
  </div>

  <div v-if="!error">
    <template v-for="(row) in filmsList">
      <div class="row">
        <template v-for="(item) in row">
          <div class="col-3">
            <q-card>
              <q-img :src="item.poster"/>
              <q-card-section>
                <div>{{item.name}}</div>
              </q-card-section>
            </q-card>
           </div>
        </template>
      </div>
    </template>
  </div>
</template>


<script>
  import dummy from './dummy';
  
  export default {
    data(){
      return {
        error: false,
        filmsList: []
      }
    },
    created(){
      // call data
      
      
      let rowItems = [];
      for(let i =0; i<dummy.length; i++){
        const filmObj = {
          name: dummy[i].title,
          poster: dummy[i].poster,
          id: dummy[i]._id
        }
        rowItems.push(filmObj);
        if(i%4==3){
          this.filmsList.push(rowItems);
          rowItems=[];
        }
      }
      console.log(this.filmsList);
    }
  }

</script>